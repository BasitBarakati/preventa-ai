import Link from "next/link";
import type { PageDefinition } from "@/lib/site-content";
import AssessmentExperience from "./AssessmentExperience";
import AssistantPreview from "./AssistantPreview";
import AuthPanel from "./AuthPanel";
import CoursePreview from "./CoursePreview";
import DashboardPreview from "./DashboardPreview";
import InquiryForm from "./InquiryForm";
import ResearchPreview from "./ResearchPreview";
import Reveal from "./Reveal";
import { ArrowIcon, CheckIcon, ShieldIcon } from "./icons";

function AssessmentVariant(path: string) {
  if (path.endsWith("/community")) return "community" as const;
  if (path.endsWith("/organization")) return "organization" as const;
  return "individual" as const;
}

export default function GenericPage({ page }: { page: PageDefinition }) {
  const isContact = page.path === "/contact";
  return (
    <main id="main-content" className="internal-page">
      <section className="page-hero">
        <div className="page-hero__mesh" aria-hidden="true" />
        <div className="container page-hero__inner">
          <nav className="breadcrumbs" aria-label="Breadcrumb"><Link href="/" prefetch={false}>Home</Link><span aria-hidden="true">/</span><span>{page.title}</span></nav>
          <p className="eyebrow"><span /> {page.eyebrow}</p>
          <h1>{page.title}</h1>
          <p>{page.description}</p>
          <div className="page-hero__actions"><Link href={isContact ? "#contact-form" : "/contact"} prefetch={false} className="button">{isContact ? "Send a request" : "Request early access"}<ArrowIcon size={18} /></Link><Link href="/platform" prefetch={false} className="button button--ghost-light">Explore the platform</Link></div>
        </div>
      </section>

      {page.notice && <div className="container notice" role="note"><ShieldIcon size={20} /><p>{page.notice}</p></div>}

      <section className="section section--light page-capabilities">
        <div className="container">
          <Reveal className="section-heading section-heading--split"><div><p className="eyebrow eyebrow--dark"><span /> WHAT IT SUPPORTS</p><h2>Knowledge, tools, and accountable action.</h2></div><p>Every capability is designed to make context, sources, limits, review status, and next steps easier to understand.</p></Reveal>
          <div className="capability-list">{page.highlights.map((item, index) => <Reveal key={item} delay={(index % 4) * 0.035}><div><span>{String(index + 1).padStart(2, "0")}</span><CheckIcon size={18} /><p>{item}</p></div></Reveal>)}</div>
        </div>
      </section>

      {page.sections && <section className="section section--pearl"><div className="container section-cards">{page.sections.map((section, index) => <Reveal key={section.title} delay={index * 0.06}><article><span>0{index + 1}</span><h2>{section.title}</h2><p>{section.body}</p></article></Reveal>)}</div></section>}

      {page.kind === "assessment" && <section className="section section--pearl"><div className="container"><AssessmentExperience variant={AssessmentVariant(page.path)} /></div></section>}
      {page.kind === "assistant" && <section className="section section--pearl"><div className="container"><AssistantPreview /></div></section>}
      {page.kind === "research" && <section className="section section--pearl"><div className="container"><ResearchPreview /></div></section>}
      {page.kind === "dashboard" && <section className="section section--pearl"><div className="container"><DashboardPreview /></div></section>}
      {page.kind === "course" && <section className="section section--pearl"><div className="container"><CoursePreview /></div></section>}
      {page.kind === "auth" && <section className="section section--pearl"><div className="container"><AuthPanel create={page.path === "/create-account"} /></div></section>}
      {isContact && <section className="section section--pearl" id="contact-form"><div className="container contact-grid"><div><p className="eyebrow eyebrow--dark"><span /> YOUR CONTEXT</p><h2>Help us understand the work.</h2><p>We review every request. Share the intended public-health use, the people who need to be involved, and the governance questions that matter.</p><div className="contact-note"><ShieldIcon size={20} /><span>Never submit personal health information through this form.</span></div></div><InquiryForm /></div></section>}

      {page.kind === "policy" && <section className="section section--pearl"><div className="container policy-content"><h2>Implementation commitments</h2><p>This page describes the intended product direction for the public preview. Production controls, policies, agreements, retention schedules, and compliance evidence will be finalized before personal or organizational data workflows are activated.</p><p>Questions, accessibility barriers, privacy requests, or concerns about AI-supported content can be directed through the <Link href="/contact">contact and escalation pathway</Link>.</p></div></section>}

      <section className="internal-cta"><div className="container"><div><p className="eyebrow"><span /> PRACTICAL NEXT STEP</p><h2>Bring the right people into the conversation.</h2><p>Responsible implementation works best when public health, community partners, privacy, accessibility, evidence, technology, and leadership are involved early.</p></div><Link href="/partnerships" prefetch={false} className="button button--light">Explore partnerships <ArrowIcon size={18} /></Link></div></section>
    </main>
  );
}

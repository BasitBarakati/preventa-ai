"use client";

import Link from "next/link";
import type { ButtonHTMLAttributes, ReactNode } from "react";
import { twMerge } from "tailwind-merge";

type Props = ButtonHTMLAttributes<HTMLButtonElement> & {
  children: ReactNode;
  href?: string;
  variant?: "primary" | "secondary" | "quiet";
};

export default function GlowingButton({ children, href, variant = "primary", className, ...props }: Props) {
  const classes = twMerge("glow-button", `glow-button--${variant}`, className);
  if (href) return <Link href={href} prefetch={false} className={classes}>{children}</Link>;
  return <button className={classes} {...props}>{children}</button>;
}

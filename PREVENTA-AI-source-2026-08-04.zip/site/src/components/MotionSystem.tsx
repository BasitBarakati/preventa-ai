"use client";

import { usePathname } from "next/navigation";
import { useEffect } from "react";

export default function MotionSystem() {
  const pathname = usePathname();

  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const coarse = window.matchMedia("(pointer: coarse)").matches;
    let destroy: (() => void) | undefined;
    let cursorFrame = 0;
    let motionTimer = 0;
    let cancelled = false;

    if (!reduce) {
      const startMotion = () => { motionTimer = window.setTimeout(() => { void Promise.all([import("lenis"), import("gsap"), import("gsap/ScrollTrigger")]).then(([lenisModule, gsapModule, triggerModule]) => {
        if (cancelled) return;
        const Lenis = lenisModule.default;
        const lenis = new Lenis({ lerp: 0.1, smoothWheel: true, wheelMultiplier: 0.82 });
        let frame = 0;
        const raf = (time: number) => { lenis.raf(time); frame = requestAnimationFrame(raf); };
        frame = requestAnimationFrame(raf);

        const gsap = gsapModule.default;
        gsap.registerPlugin(triggerModule.ScrollTrigger);
        const context = gsap.context(() => {
          gsap.utils.toArray<HTMLElement>("[data-reveal]").forEach((element) => {
            gsap.fromTo(element, { y: 34, opacity: 0 }, { y: 0, opacity: 1, duration: .85, ease: "power3.out", scrollTrigger: { trigger: element, start: "top 88%", once: true } });
          });
        });
        destroy = () => { cancelAnimationFrame(frame); lenis.destroy(); context.revert(); };
      }); }, 700); };
      if (document.readyState === "complete") startMotion();
      else window.addEventListener("load", startMotion, { once: true });
    }

    const pointer = (event: PointerEvent) => {
      if (coarse || reduce) return;
      cancelAnimationFrame(cursorFrame);
      cursorFrame = requestAnimationFrame(() => {
        document.documentElement.style.setProperty("--pointer-x", `${event.clientX}px`);
        document.documentElement.style.setProperty("--pointer-y", `${event.clientY}px`);
      });
    };
    window.addEventListener("pointermove", pointer, { passive: true });
    return () => { cancelled = true; window.clearTimeout(motionTimer); destroy?.(); cancelAnimationFrame(cursorFrame); window.removeEventListener("pointermove", pointer); };
  }, [pathname]);

  return null;
}

import { ChartIcon, CheckIcon, ShieldIcon } from "./icons";

const rows = [
  ["Wellbeing domains reviewed", "4 of 6", "In progress"],
  ["Evidence sources attached", "12", "Review required"],
  ["Action items assigned", "3", "Draft"],
] as const;

export default function DashboardPreview() {
  return (
    <section className="dashboard-preview" aria-label="Accessible dashboard interface preview">
      <div className="dashboard-preview__sidebar" aria-hidden="true"><ShieldIcon size={22} /><i /><i /><i /><i /><i /></div>
      <div className="dashboard-preview__main">
        <div className="dashboard-preview__heading"><div><small>INTERFACE PREVIEW</small><h2>Public health action dashboard</h2></div><span><CheckIcon size={16} /> Review status visible</span></div>
        <div className="dashboard-preview__cards"><div><span>Assessment stage</span><strong>Understand</strong><small>4 domains reviewed</small></div><div><span>Evidence status</span><strong>12 sources</strong><small>3 need verification</small></div><div><span>Action planning</span><strong>Draft</strong><small>Owner review pending</small></div></div>
        <div className="dashboard-preview__visuals">
          <div className="bar-chart" role="img" aria-label="Sample domain readiness values: movement 78, sleep 62, nutrition 71, coping 54.">
            <h3><ChartIcon size={18} /> Domain readiness <span>Sample data</span></h3>
            {[78, 62, 71, 54].map((value, index) => <div key={value}><span>{["Movement", "Sleep", "Nutrition", "Coping"][index]}</span><i><b style={{ width: `${value}%` }} /></i><strong>{value}</strong></div>)}
          </div>
          <div className="action-list"><h3>Human review queue</h3>{["Confirm local context", "Verify three evidence sources", "Approve next-step language"].map((item, index) => <div key={item}><span>{index + 1}</span><p>{item}<small>{index === 0 ? "Community lead" : index === 1 ? "Evidence reviewer" : "Program owner"}</small></p></div>)}</div>
        </div>
        <table className="data-table"><caption>Sample dashboard data table</caption><thead><tr><th>Measure</th><th>Value</th><th>Status</th></tr></thead><tbody>{rows.map((row) => <tr key={row[0]}>{row.map((cell) => <td key={cell}>{cell}</td>)}</tr>)}</tbody></table>
        <p className="research-note">Development-only sample data. This preview does not contain personal health information or measured platform outcomes.</p>
      </div>
    </section>
  );
}

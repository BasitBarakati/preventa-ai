"use client";

import Link from "next/link";
import { useState } from "react";
import { products } from "@/lib/site-content";
import { ArrowIcon, ChartIcon, CheckIcon, ShieldIcon } from "./icons";

const previewRows = [
  ["Evidence quality", "Reviewed", 86],
  ["Community context", "Needs review", 64],
  ["Implementation readiness", "In progress", 72],
] as const;

export default function ProductPreview() {
  const [active, setActive] = useState(0);
  const [title, href, description] = products[active];

  return (
    <div className="product-preview">
      <div className="product-preview__tabs" role="tablist" aria-label="Product previews">
        {products.map(([label], index) => (
          <button
            key={label}
            id={`product-tab-${index}`}
            role="tab"
            aria-selected={active === index}
            aria-controls="product-panel"
            tabIndex={active === index ? 0 : -1}
            onClick={() => setActive(index)}
          >
            <span>{String(index + 1).padStart(2, "0")}</span>{label}
          </button>
        ))}
      </div>

      <div id="product-panel" role="tabpanel" aria-labelledby={`product-tab-${active}`} className="product-preview__panel">
        <div className="preview-window">
          <div className="preview-window__bar"><span /><span /><span /><strong>PREVENTA AI · INTERFACE PREVIEW</strong></div>
          <div className="preview-window__content">
            <aside aria-hidden="true">
              <div className="preview-mark"><ShieldIcon size={20} /></div>
              <i /><i /><i /><i />
            </aside>
            <div className="preview-main">
              <div className="preview-heading">
                <div><small>WORKSPACE</small><h3>{title}</h3></div>
                <span><CheckIcon size={16} /> Human review on</span>
              </div>
              <div className="preview-metrics">
                <div><small>Current stage</small><strong>Understand</strong><span>Evidence organized</span></div>
                <div><small>Sources</small><strong>Visible</strong><span>Citations attached</span></div>
                <div><small>Next review</small><strong>Required</strong><span>Before export</span></div>
              </div>
              <div className="preview-chart" aria-label="Sample readiness overview. Evidence quality 86 percent, community context 64 percent, implementation readiness 72 percent.">
                <div className="preview-chart__title"><ChartIcon size={18} /> Explainable readiness overview <span>Sample data</span></div>
                {previewRows.map(([label, state, value]) => (
                  <div className="preview-chart__row" key={label}>
                    <span>{label}</span><div><i style={{ width: `${value}%` }} /></div><b>{state}</b>
                  </div>
                ))}
              </div>
              <details className="sr-table">
                <summary>View sample data as a table</summary>
                <table><thead><tr><th>Measure</th><th>Status</th><th>Sample value</th></tr></thead><tbody>{previewRows.map(([label, state, value]) => <tr key={label}><td>{label}</td><td>{state}</td><td>{value}%</td></tr>)}</tbody></table>
              </details>
            </div>
          </div>
        </div>
        <div className="product-preview__copy">
          <p>{description}</p>
          <Link href={href} prefetch={false}>Explore this experience <ArrowIcon size={18} /></Link>
          <small>Illustrative interface using development-only sample data. No personal health information.</small>
        </div>
      </div>
    </div>
  );
}

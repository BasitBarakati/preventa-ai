import { BookIcon, CheckIcon, ShieldIcon } from "./icons";

export default function ResearchPreview() {
  return (
    <section className="research-preview" aria-label="Research workspace interface preview">
      <div className="research-preview__header"><div><BookIcon size={21} /><strong>Evidence synthesis workspace</strong></div><span>Preview · synthetic project</span></div>
      <div className="research-preview__body">
        <aside><p>WORKFLOW</p>{["Protocol", "Search", "Screen", "Extract", "Synthesize", "Verify"].map((item, index) => <span className={index < 3 ? "is-active" : ""} key={item}><i>{index < 2 ? <CheckIcon size={13} /> : index + 1}</i>{item}</span>)}</aside>
        <div className="research-preview__main">
          <div className="research-project"><div><small>DEVELOPMENT PROJECT</small><h3>Community-centred AI implementation</h3></div><span><ShieldIcon size={16} /> Human verification required</span></div>
          <div className="research-stats"><div><strong>Protocol</strong><span>Eligibility criteria documented</span></div><div><strong>Sources</strong><span>Primary databases identified</span></div><div><strong>Audit trail</strong><span>Decision log enabled</span></div></div>
          <div className="research-table"><div className="research-table__head"><span>Candidate record</span><span>Decision</span><span>Reason</span></div>{[
            ["Implementation framework for public health AI", "Include", "Matches population and intervention"],
            ["Clinical diagnostic model performance", "Exclude", "Outside intended public-health scope"],
            ["Community governance for health data", "Review", "Requires second reviewer"],
          ].map((row) => <div key={row[0]}>{row.map((cell) => <span key={cell}>{cell}</span>)}</div>)}</div>
          <p className="research-note">Illustrative records only. No literature database, model, or automated screening service is connected.</p>
        </div>
      </div>
    </section>
  );
}

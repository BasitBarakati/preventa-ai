"use client";

import { Canvas, useFrame, useLoader } from "@react-three/fiber";
import { useMemo, useRef, useSyncExternalStore } from "react";
import * as THREE from "three";

const nodePositions: [number, number, number][] = [
  [-2.8, 1.65, -0.3],
  [2.75, 1.35, 0.15],
  [3.05, -1.45, -0.15],
  [-2.65, -1.75, 0.1],
  [0, -2.7, -0.4],
];

function subscribeReducedMotion(callback: () => void) {
  const query = window.matchMedia("(prefers-reduced-motion: reduce)");
  query.addEventListener("change", callback);
  return () => query.removeEventListener("change", callback);
}

function getReducedMotion() {
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

function IntelligenceNetwork() {
  const group = useRef<THREE.Group>(null);
  const ring = useRef<THREE.Mesh>(null);
  const logoTexture = useLoader(THREE.TextureLoader, "/brand/preventa-ai-symbol.png");
  const reducedMotion = useSyncExternalStore(subscribeReducedMotion, getReducedMotion, () => true);

  const lines = useMemo(() => {
    const points: number[] = [];
    for (const position of nodePositions) points.push(0, 0, 0, ...position);
    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute("position", new THREE.Float32BufferAttribute(points, 3));
    return geometry;
  }, []);

  const particles = useMemo(() => {
    const data = new Float32Array(120 * 3);
    for (let i = 0; i < 120; i += 1) {
      const angle = i * 2.399963;
      const radius = 2.2 + ((i * 47) % 100) / 38;
      data[i * 3] = Math.cos(angle) * radius;
      data[i * 3 + 1] = Math.sin(angle) * radius * 0.62;
      data[i * 3 + 2] = -1.2 + ((i * 31) % 100) / 38;
    }
    return data;
  }, []);

  useFrame(({ clock, pointer }) => {
    if (!group.current || reducedMotion) return;
    const elapsed = clock.getElapsedTime();
    group.current.rotation.y = Math.sin(elapsed * 0.22) * 0.09 + pointer.x * 0.08;
    group.current.rotation.x = Math.cos(elapsed * 0.18) * 0.025 - pointer.y * 0.04;
    group.current.position.y = Math.sin(elapsed * 0.55) * 0.055;
    if (ring.current) ring.current.rotation.z = elapsed * 0.055;
  });

  return (
    <group ref={group}>
      <points>
        <bufferGeometry><bufferAttribute attach="attributes-position" args={[particles, 3]} /></bufferGeometry>
        <pointsMaterial color="#6bd8d1" size={0.028} transparent opacity={0.52} depthWrite={false} />
      </points>

      <lineSegments geometry={lines}>
        <lineBasicMaterial color="#5bcac4" transparent opacity={0.35} />
      </lineSegments>

      <mesh ref={ring} rotation={[1.18, 0.12, 0]}>
        <torusGeometry args={[3.28, 0.012, 8, 160]} />
        <meshBasicMaterial color="#8bb7d4" transparent opacity={0.25} />
      </mesh>
      <mesh rotation={[1.34, 0.38, 0.85]}>
        <torusGeometry args={[2.72, 0.009, 8, 160]} />
        <meshBasicMaterial color="#31b7b1" transparent opacity={0.28} />
      </mesh>

      <mesh position={[0, 0, -0.05]}>
        <boxGeometry args={[2.28, 2.48, 0.12]} />
        <meshStandardMaterial color="#ffffff" roughness={0.24} metalness={0.04} />
      </mesh>
      <mesh position={[0, 0, 0.02]}>
        <planeGeometry args={[2.22, 2.42]} />
        <meshBasicMaterial map={logoTexture} toneMapped={false} />
      </mesh>

      {nodePositions.map((position, index) => (
        <group position={position} key={index}>
          <mesh>
            <sphereGeometry args={[0.16, 24, 24]} />
            <meshStandardMaterial color={index === 2 ? "#47d5cb" : "#c6e4f4"} emissive={index === 2 ? "#0d8f89" : "#214a6a"} emissiveIntensity={0.45} roughness={0.22} />
          </mesh>
          <mesh scale={1.65}>
            <sphereGeometry args={[0.16, 18, 18]} />
            <meshBasicMaterial color="#5bd3cb" transparent opacity={0.1} depthWrite={false} />
          </mesh>
        </group>
      ))}
    </group>
  );
}

export default function IntelligenceScene() {
  return (
    <Canvas
      dpr={[1, 1.5]}
      camera={{ position: [0, 0, 8.2], fov: 43 }}
      gl={{ antialias: true, alpha: true, powerPreference: "high-performance" }}
      frameloop="always"
    >
      <ambientLight intensity={1.2} />
      <directionalLight position={[3, 4, 6]} intensity={2.1} color="#ffffff" />
      <pointLight position={[-4, -2, 3]} intensity={15} distance={9} color="#35bdb6" />
      <IntelligenceNetwork />
    </Canvas>
  );
}

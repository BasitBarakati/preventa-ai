import Link from "next/link";
import type { ComponentType } from "react";
import {
  Activity, ArrowRight, BookOpenCheck, BrainCircuit, Building2, CheckCircle2, ClipboardList,
  CloudSun, DatabaseZap, Dna, FileSearch, FlaskConical, GraduationCap, HandHeart, HeartPulse,
  Landmark, Leaf, Network, Scale, ShieldCheck, Sparkles, Sprout, Syringe, UsersRound,
} from "lucide-react";
import PersonaHero from "./PersonaHero";
import ProductPreview from "./ProductPreview";
import ResearchPreview from "./ResearchPreview";
import CoursePreview from "./CoursePreview";
import GlassCard from "./ui/GlassCard";
import GlowingButton from "./ui/GlowingButton";
import AssessmentWizard from "./ui/AssessmentWizard";
import { audiences, pillars } from "@/lib/site-content";

const pillarIcons: ComponentType<{ size?: number }>[] = [ClipboardList, BrainCircuit, HandHeart, FlaskConical, GraduationCap];
const assessmentModules = [
  { icon: HeartPulse, title: "Individual & Family Wellbeing", body: "A private reflection across six everyday wellbeing domains, followed by an accessible pattern view and practical next-step framework.", meta: ["6 wellbeing domains", "Anonymous option", "Printable summary"], href: "/situation-assessment/individual-and-family" },
  { icon: UsersRound, title: "Community Assessment", body: "Organize risks, protective factors, assets, priorities, equity considerations, services, partnerships, gaps, and program learning.", meta: ["Needs + strengths", "Partner mapping", "Gap analysis"], href: "/situation-assessment/community" },
  { icon: Building2, title: "Organization & Workplace", body: "Understand psychological safety, culture, leadership trust, burnout indicators, change readiness, and responsible AI capability.", meta: ["Workforce signals", "AI readiness", "Repeat measures"], href: "/situation-assessment/organization" },
] as const;

const implementationHubs = [
  { icon: BrainCircuit, title: "Transformation & Automation", text: "Governed workflows that reduce administrative burden while preserving accountability." },
  { icon: HeartPulse, title: "Mental Wellbeing", text: "Prevention, promotion, navigation, and trauma-aware planning without diagnosis." },
  { icon: HandHeart, title: "Substance Use & Addiction", text: "Non-stigmatizing evidence, harm-reduction resources, and service pathways." },
  { icon: CloudSun, title: "Healthy Environments", text: "Connect exposure, community context, equity, protective factors, and action." },
  { icon: Dna, title: "Healthy Sexuality", text: "Inclusive education, service navigation, and program-planning support." },
  { icon: Syringe, title: "Immunization", text: "Evidence-informed education, access analysis, program planning, and monitoring." },
] as const;

const researchTools = ["Literature screening", "Evidence synthesis", "Research summaries", "Qualitative support", "Protocol assistance", "Validation checklists", "Bias & fairness review", "Auditable exports"];
const courses = [
  ["AI in Research & Evidence Synthesis", "Frame, screen, synthesize, cite, and verify.", "/courses/ai-in-research-and-evidence-synthesis"],
  ["AI in Health Promotion", "Move from needs and evidence to responsible programs.", "/courses/ai-in-health-promotion"],
  ["AI in Epidemiology", "Understand data quality, modelling, bias, and uncertainty.", "/courses/ai-in-epidemiology"],
  ["AI in Knowledge Translation", "Create accessible products without losing nuance.", "/courses/ai-in-knowledge-translation"],
] as const;

function SectionIntro({ eyebrow, title, text }: { eyebrow: string; title: string; text: string }) {
  return <div className="lux-section-intro" data-reveal><p className="lux-eyebrow"><span /> {eyebrow}</p><h2>{title}</h2><p>{text}</p></div>;
}

export default function HomePage() {
  return (
    <main id="main-content" className="luxury-home">
      <PersonaHero />

      <section className="lux-section pillar-overview" id="platform">
        <div className="container">
          <SectionIntro eyebrow="THE PREVENTA ECOSYSTEM" title="Five intelligence layers. One accountable path to action." text="Knowledge explains the context. Tools structure the work. Human-reviewed action turns insight into practical next steps." />
          <div className="lux-pillar-grid">{pillars.map((pillar, index) => { const Icon = pillarIcons[index]; return <Link key={pillar.title} href={pillar.href} prefetch={false} className="lux-pillar-card" data-reveal><span className="lux-pillar-card__number">{pillar.number}</span><div className="lux-icon"><Icon size={23} /></div><h3>{pillar.title}</h3><p>{pillar.description}</p><small>{pillar.signal}</small><ArrowRight className="lux-pillar-card__arrow" size={19} /></Link>; })}</div>
        </div>
      </section>

      <section className="lux-section audience-section">
        <div className="container audience-layout">
          <SectionIntro eyebrow="ROLE-AWARE BY DESIGN" title="A clearer starting point for every level of public health." text="Choose a pathway in the navigation. The context changes, while evidence standards, accessibility, privacy, and human accountability remain consistent." />
          <div className="audience-orbit" data-reveal><div className="audience-orbit__core"><Network size={28} /><strong>Shared public-health intelligence</strong></div>{audiences.map(([title, description], index) => <GlassCard key={title} className={`audience-orbit__item audience-orbit__item--${index + 1}`}><span>0{index + 1}</span><h3>{title}</h3><p>{description}</p></GlassCard>)}</div>
        </div>
      </section>

      <section className="lux-section assessment-studio" id="assessment">
        <div className="container">
          <SectionIntro eyebrow="01 · SITUATION ASSESSMENT" title="See the whole context before choosing the next move." text="Structured workflows make needs, strengths, risks, services, readiness, and opportunities easier to review—without turning public-health complexity into a single opaque score." />
          <div className="assessment-module-grid">{assessmentModules.map(({ icon: Icon, title, body, meta, href }) => <GlassCard key={title} glow="teal" className="assessment-module" data-reveal><div className="lux-icon"><Icon /></div><h3>{title}</h3><p>{body}</p><ul>{meta.map((item) => <li key={item}><CheckCircle2 size={14} />{item}</li>)}</ul><Link href={href} prefetch={false}>Explore module <ArrowRight size={16} /></Link></GlassCard>)}</div>
          <div className="assessment-demo" data-reveal><div className="assessment-demo__heading"><div><p className="lux-eyebrow">INTERACTIVE PREVIEW</p><h3>Individual & Family Wellbeing Assessment</h3></div><span><ShieldCheck size={16} /> Responses stay in this browser session</span></div><AssessmentWizard /></div>
        </div>
      </section>

      <section className="lux-section implementation-section" id="implementation">
        <div className="container">
          <SectionIntro eyebrow="02 · HEALTH & AI IMPLEMENTATION" title="From responsible concept to governed public-health workflow." text="Six implementation hubs connect purpose, evidence, readiness, privacy, oversight, evaluation, and the people affected by change." />
          <div className="implementation-grid">{implementationHubs.map(({ icon: Icon, title, text }, index) => <GlassCard key={title} glow={index === 0 ? "violet" : "none"} className="implementation-card" data-reveal><span>0{index + 1}</span><Icon /><h3>{title}</h3><p>{text}</p><div className="implementation-path"><i /><i /><i /><b>Review gate</b></div></GlassCard>)}</div>
          <div className="workflow-strip" data-reveal><div><span>01</span><strong>Define</strong><p>Purpose, users, data, intended use, and boundaries.</p></div><ArrowRight /><div><span>02</span><strong>Govern</strong><p>Evidence, privacy, bias, access, and human authority.</p></div><ArrowRight /><div><span>03</span><strong>Implement</strong><p>Prototype, validate, train, monitor, and improve.</p></div></div>
        </div>
      </section>

      <section className="lux-section indigenous-section" id="indigenous-health">
        <div className="container indigenous-layout">
          <div data-reveal><p className="lux-eyebrow"><span /> 03 · INDIGENOUS HEALTH & WELLBEING</p><h2>Community authority is the foundation—not a feature.</h2><p>Preventa AI is being designed to support relationship-based co-design, culturally safe workflows, wholistic wellbeing, and community control over data and decisions. It does not speak for any Nation or community.</p><div className="governance-tags"><span>OCAP® principles</span><span>Two-Eyed Seeing</span><span>Indigenous Advisory Circle</span><span>Community data authority</span></div><GlowingButton href="/indigenous-health" variant="secondary">Explore the governance pathway <ArrowRight size={17} /></GlowingButton></div>
          <div className="indigenous-framework" data-reveal><div className="framework-line" aria-hidden="true" />{[{ icon: Sprout, title: "Wholistic health", text: "Physical, mental, emotional, spiritual, relational, and community wellbeing." }, { icon: Leaf, title: "Land", text: "Community-defined connections among land, identity, food, stewardship, and healing." }, { icon: Landmark, title: "Culture", text: "Language, teaching, identity, ceremony, relationships, and strengths—defined locally." }, { icon: Scale, title: "Social determinants", text: "Structural conditions, access, safety, discrimination, and community strengths in context." }].map(({ icon: Icon, title, text }) => <GlassCard key={title}><Icon /><div><h3>{title}</h3><p>{text}</p></div></GlassCard>)}</div>
        </div>
      </section>

      <section className="lux-section research-section" id="research">
        <div className="container">
          <SectionIntro eyebrow="04 · AI IN RESEARCH & RISK PREDICTION" title="Accelerate evidence work. Keep verification visible." text="A controlled workspace for screening, synthesis, research support, and responsible population-level modelling—with explicit validation and fairness gates." />
          <div className="research-capabilities">{researchTools.map((item, index) => <div key={item} data-reveal><span>{String(index + 1).padStart(2, "0")}</span><CheckCircle2 size={16} /><strong>{item}</strong></div>)}</div>
          <div className="lux-product-shell" data-reveal><ResearchPreview /></div>
          <p className="research-boundary"><ShieldCheck size={16} /> Public-phase workspaces use synthetic, open, or explicitly approved data only. No live personal-health prediction is activated.</p>
        </div>
      </section>

      <section className="lux-section learning-section" id="learning">
        <div className="container">
          <SectionIntro eyebrow="05 · COURSES & WORKFORCE LEARNING" title="Build practical AI capability that stays with your team." text="Role-aware learning blends concise concepts, public-health scenarios, applied exercises, knowledge checks, reflection, and transparent certificate criteria." />
          <div className="course-grid-v2">{courses.map(([title, text, href], index) => <Link key={title} href={href} prefetch={false} className="course-card-v2" data-reveal><span>PATH 0{index + 1}</span><BookOpenCheck /><h3>{title}</h3><p>{text}</p><div><small>4 MODULES · APPLIED EXERCISE · KNOWLEDGE CHECK</small><ArrowRight /></div></Link>)}</div>
          <div className="lux-product-shell course-shell" data-reveal><CoursePreview /></div>
        </div>
      </section>

      <section className="lux-section product-section">
        <div className="container"><SectionIntro eyebrow="CONNECTED PRODUCT EXPERIENCES" title="One governed workspace. Many public-health tasks." text="Explore interface concepts for dashboards, reporting, assistance, evidence, research, and learning. Development data is labelled and never presented as real impact." /><div className="lux-product-shell" data-reveal><ProductPreview /></div></div>
      </section>

      <section className="lux-section trust-section">
        <div className="container trust-layout">
          <div data-reveal><p className="lux-eyebrow"><span /> RESPONSIBLE BY DESIGN</p><h2>Useful AI begins with boundaries people can inspect.</h2><p>Preventa AI is designed to support PHIPA- and PIPEDA-aligned implementation. Formal compliance depends on deployment, contracts, configuration, operational controls, and legal review.</p><GlowingButton href="/governance-and-ethics" variant="secondary">Review governance & ethics <ArrowRight size={17} /></GlowingButton></div>
          <div className="trust-grid" data-reveal>{["Evidence-grounded responses", "Visible citations", "Human review", "Data minimization", "Role-based access", "Encryption architecture", "Audit-log readiness", "Clear AI limitations", "No diagnosis", "Human escalation"].map((item) => <div key={item}><ShieldCheck size={16} /><span>{item}</span></div>)}</div>
        </div>
      </section>

      <section className="lux-final-cta"><div className="container" data-reveal><Sparkles /><p className="lux-eyebrow">BUILD WITH ACCOUNTABILITY</p><h2>Build the Next Generation of Public Health.</h2><p>Bring responsible AI, practical assessment tools, evidence, and workforce learning into one trusted platform.</p><div><GlowingButton href="/create-account">Request early access <ArrowRight size={17} /></GlowingButton><GlowingButton href="/partnerships" variant="secondary">Partner with Preventa AI</GlowingButton></div></div></section>
    </main>
  );
}

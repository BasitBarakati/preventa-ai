"use client";

import { useMemo, useState } from "react";
import { CheckIcon, ShieldIcon } from "./icons";

const domains = {
  individual: ["Physical activity", "Healthy eating", "Smoking", "Alcohol and substance use", "Sleep", "Stress and coping"],
  community: ["Risks and protective factors", "Priorities and needs", "Community strengths and assets", "Equity considerations", "Programs and services", "Partnerships and gaps"],
  organization: ["Employee satisfaction", "Psychological safety", "Burnout indicators", "Leadership trust", "Change readiness", "AI readiness"],
} as const;

type Variant = keyof typeof domains;

export default function AssessmentExperience({ variant }: { variant: Variant }) {
  const questions = domains[variant];
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const finished = step >= questions.length;
  const completed = Object.keys(answers).length;
  const average = useMemo(() => completed ? Object.values(answers).reduce((sum, value) => sum + value, 0) / completed : 0, [answers, completed]);

  const choose = (value: number) => {
    setAnswers((current) => ({ ...current, [step]: value }));
  };

  const next = () => {
    if (answers[step]) setStep((current) => Math.min(current + 1, questions.length));
  };

  const restart = () => {
    setAnswers({});
    setStep(0);
  };

  return (
    <section className="tool-shell" aria-labelledby="assessment-preview-title">
      <div className="tool-shell__topline">
        <span><ShieldIcon size={18} /> Privacy-preserving interface preview</span>
        <span>Nothing is transmitted or saved</span>
      </div>
      <div className="assessment-tool">
        <aside>
          <p>ASSESSMENT PATH</p>
          {questions.map((question, index) => (
            <button key={question} type="button" className={index === step ? "is-current" : index < step ? "is-complete" : ""} onClick={() => index <= completed && setStep(index)}>
              <span>{index < completed ? <CheckIcon size={14} /> : index + 1}</span>{question}
            </button>
          ))}
        </aside>
        <div className="assessment-tool__main">
          {!finished ? (
            <>
              <div className="assessment-progress"><span style={{ width: `${(completed / questions.length) * 100}%` }} /><b>{completed} of {questions.length} complete</b></div>
              <p className="eyebrow eyebrow--dark"><span /> DEMONSTRATION QUESTION</p>
              <h2 id="assessment-preview-title">{questions[step]}</h2>
              <p>For this interface preview, how ready do you feel to understand and take a practical next step in this area?</p>
              <fieldset>
                <legend>Select one response</legend>
                <div className="scale-options">
                  {[1, 2, 3, 4, 5].map((value) => (
                    <label key={value} className={answers[step] === value ? "is-selected" : ""}>
                      <input type="radio" name={`question-${step}`} value={value} checked={answers[step] === value} onChange={() => choose(value)} />
                      <span>{value}</span><small>{value === 1 ? "Not ready" : value === 5 ? "Ready" : ""}</small>
                    </label>
                  ))}
                </div>
              </fieldset>
              <div className="assessment-actions">
                <button type="button" className="button button--secondary" disabled={step === 0} onClick={() => setStep((current) => Math.max(0, current - 1))}>Back</button>
                <button type="button" className="button" disabled={!answers[step]} onClick={next}>{step === questions.length - 1 ? "View example summary" : "Continue"}</button>
              </div>
            </>
          ) : (
            <div className="assessment-summary">
              <p className="eyebrow eyebrow--dark"><span /> EXAMPLE SUMMARY</p>
              <h2 id="assessment-preview-title">Your reflection is ready to review.</h2>
              <p>This local preview shows how a completed workflow could organize responses. It does not interpret health status, assess risk, or provide a diagnosis.</p>
              <div className="summary-score"><span>Self-reported readiness</span><strong>{average.toFixed(1)}<small>/5</small></strong></div>
              <h3>Suggested next-step framework</h3>
              <ul><li>Choose one domain that feels achievable.</li><li>Review approved evidence and local resources.</li><li>Discuss concerns with an appropriate professional or community support.</li><li>Reassess when the context changes.</li></ul>
              <div className="assessment-actions"><button type="button" className="button button--secondary" onClick={restart}>Restart preview</button><button type="button" className="button" onClick={() => window.print()}>Print this preview</button></div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
